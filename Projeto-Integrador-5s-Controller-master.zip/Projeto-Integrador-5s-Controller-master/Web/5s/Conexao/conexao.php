<?php

$servername =  "10.26.45.157"; //server local
$username = "root";
$password = "pti@2018";
$database = "adega";

//Create connection
$conexao = mysqli_connect($servername, $username, $password, $database);
?>
